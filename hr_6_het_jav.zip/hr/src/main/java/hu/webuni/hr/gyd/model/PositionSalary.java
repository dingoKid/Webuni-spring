package hu.webuni.hr.gyd.model;

public interface PositionSalary {
	
	String getPosition();
	int getAverageSalary();

}
