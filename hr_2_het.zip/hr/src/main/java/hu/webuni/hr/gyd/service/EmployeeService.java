package hu.webuni.hr.gyd.service;

import hu.webuni.hr.gyd.model.Employee;

public interface EmployeeService {

	int getPayRaisePercent(Employee employee);
	
}
