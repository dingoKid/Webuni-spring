package hu.webuni.hr.gyd.dto;

public interface PositionSalaryDto {
	
	String getPosition();
	int getAverageSalary();

}
