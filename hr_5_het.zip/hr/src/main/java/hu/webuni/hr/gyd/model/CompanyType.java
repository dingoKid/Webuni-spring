package hu.webuni.hr.gyd.model;

public enum CompanyType{
	BT,
	KFT,
	ZRT,
	NYRT
}